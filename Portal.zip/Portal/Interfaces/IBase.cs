﻿namespace Portal.Interfaces
{
    public interface IBase
    {
        public ICompanyRequest CompanyRequest { get; set; }
    }
}
