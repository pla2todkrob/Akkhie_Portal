﻿namespace Portal.Shared.Models.DTOs.Shared
{
    internal class FileUploadDto
    {
    }
}
